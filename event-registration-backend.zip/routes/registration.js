const express = require('express');
const router = express.Router();
const Registration = require('../models/Registration');

router.post('/', async (req, res) => {
  try {
    const newRegistration = new Registration(req.body);
    const saved = await newRegistration.save();
    res.status(201).json(saved);
  } catch (error) {
    console.error('Error saving registration:', error.message);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;